$(document).ready(function() {
	// open and close the booking form if we are in the iPad Portrait view
	$("#tabBookingsClose").click(function() {
		$("#bookingTab").trigger("click");
	});
	$("#bookingTab").click(function() {
		var width = $(window).width();
		if (width > 480 && width < 840) {
			if ($("#bookingTabs, #homeSpecials").hasClass("opened")) {
				$("#bookingTabs, #homeSpecials").removeClass("opened");
				//$(this).html('BOOK A FLIGHT');
			} else {
				$("#bookingTabs, #homeSpecials").addClass("opened");
				//$(this).html('&times;');
			}
		} else {
			$("#bookingTabs, #homeSpecials").removeClass("opened");
			//$(this).html('BOOK A FLIGHT');
		}
	});

	$(window).resize(function() {
		var width = $(this).width();
		var valid = $("#bookingTabs, #homeSpecials").hasClass("opened");
		if (width > 480 && width < 840 && valid) {
			//$('#bookingTab').html('&times;');
		} else {
			//$('#bookingTab').html('BOOK A FLIGHT');
			$("#bookingTabs, #homeSpecials").removeClass("opened");
		}
	});

	// browser caching bug.
	/* 
		We need to force a reset (some = default values like cities and country.) 
		on the form to avoid the browser caching a previously selected option when returning to the page on backspace.
	*/
	$("#depCountry").val("ZA");
	$("#arrCountry").val("ZA");
	$("#economy").val("0");
	$("#adults").val("1");
	$("#children").val("0");
	$("#infants").val("0");
	$("#return").val("");

	$("body").on("click", ".submitter", function() {
		// Check if this is a Book Now button or the homepage booking form.
		var booknowButton = false;
		if ($("#booknowForm").hasClass("BookNowTrue")) {
			booknowButton = true;
		}

		//Construct the URL builder for SAA redirect.
		// urlbuilder();

		// grab what is currently available for the url.
		var triptype = "Single";
		var returndate = "na";
		var Arriving = $("#toair").val();
		var Departing = $("#fromair").val();
		var Adults = $("#adults").val();
		var Children = $("#children").val();
		var Infants = $("#infants").val();

		// we need to ammend the dates to SAA's date format (example: 25-Nov+2015)!
		var leave = $("#date-pick-leave").val();
		leave2 = leave.split(" ");
		leaving = leave2[0] + "-" + leave2[1] + "+" + leave2[2];

		var Economy = $("#economy").val();
		var customer = $("#customer").val();
		var thispage = $("#thispage").val();

		// Set the trip type ( one way or return?)
		var tripOption = $("#flighttype").val();
		if (tripOption == "return") {
			triptype = "Return";
		} else {
			// we only want one way
			returndate = "na";
			triptype = "Single";
		}
		// Check that dates are all filled in and that return is not before or on departure date
		var dateError = checkDatesAreCorrect();

		// Check validation of form : cannot have 2 of the same destinations and muct select a city for both departing and arriving.
		var destinationError = false;
		if (!booknowButton) {
			//If submitted from a book now window we do not check Destinations as the Arriving and Departing are pre-populated

			if (Arriving == Departing) {
				destinationError =
					"Please make sure the Departing and Arriving City are not the same.";
				$("#departCity").addClass("err");
				$("#arrCity").addClass("err");
			} else {
				$("#departCity").removeClass("err");
				$("#arrCity").removeClass("err");
			}
			if (Arriving == "selectcity" || Departing == "selectcity") {
				destinationError =
					"Please select a Departing and Arriving City before submitting.";
				if (Arriving == "selectcity") {
					$("#arrCity").addClass("err");
				} else {
					$("#arrCity").removeClass("err");
				}
				if (Departing == "selectcity") {
					$("#departCity").addClass("err");
				} else {
					$("#departCity").removeClass("err");
				}
			}
		}

		// Check if no errors before submitting the form - otherwise alert the customer to the problems in his imputs.
		if (destinationError == false && dateError == false) {
			alert("Bet you did not think this booking form would really work, eh!");

			var getFullpath = document.domain;
			var GETstring = urlbuilder();
			// console.log('http://www.flysaa.com/za/en/flightSearch!deepLinkingFltAvailabilty.action?' + GETstring);
			window.open(
				"http://www.flysaa.com/za/en/flightSearch!deepLinkingFltAvailabilty.action?" +
					GETstring,
				"_blank"
			); // Goes straight to SAA booking
		} else {
			// Display the form errors for the user...
			if (destinationError !== false) {
				alert(destinationError);
			}
			if (dateError !== false) {
				alert(dateError);
			}
		}
	}); // end .submitter click function

	$("body").on("focus", "#date-pick-leave", function() {
		datepickr("#date-pick-leave", {
			dateFormat: "d M Y",
			minDate: new Date().getTime()
		});
	});
	$("body").on("focus", "#date-pick-return", function() {
		datepickr("#date-pick-return", {
			dateFormat: "d M Y",
			minDate: new Date().getTime()
		});
	});

	// form change functions
	// $('body').on('click','#booknowForm', function() { urlbuilder(); });

	$("#depCountry").change(function() {
		var country = $("option:selected", this).html();
		updateDeparting(country);
	});

	$("#arrCountry").change(function() {
		var country = $("option:selected", this).html();
		updateArriving(country);
	});

	$("#departCity").change(function() {
		var city = $(this).val();
		updateDepartingAirport(city);
		// urlbuilder();
	});

	$("#arrCity").change(function() {
		var city = $(this).val();
		updateArrivingAirport(city);
		// urlbuilder();
	});

	$("body").on("click", ".onewaySel", function() {
		$("#returndate").hide();
		$("#onewayOption").attr("checked", true);
		$("#returnOption").attr("checked", false);
		$("#flighttype").val("oneway");
		$(".expander").css("min-height", "105px");
		// urlbuilder();
	});

	$("body").on("click", ".returnSel", function() {
		$("#returndate").show();
		$("#returnOption").attr("checked", true);
		$("#onewayOption").attr("checked", false);
		$("#flighttype").val("return");
		$(".expander").css("min-height", "135px");
		// urlbuilder();
	});

	// Fire these functions if we can find the tabs
	var tabsExists = $("#bookingTabs").length;
	if (tabsExists > 0) {
		updateDeparting("South Africa"); // default departing country to South Africa
		updateArriving("South Africa"); // default arriving country to South Africa
		// urlbuilder();
	}
}); // End on page load function

function checkDatesAreCorrect() {
	var dateError = false;
	var tripOption = $("#flighttype").val();
	// work out if we are inserting a return option
	if (tripOption == "return") {
		returndate = $("#date-pick-return").val();
		// check for return date errors?
		if (returndate == "") {
			dateError = "Please select the date you wish to return on.";
			$("#date-pick-return").addClass("err");
		} else {
			$("#date-pick-return").removeClass("err");

			// check that return date does not come before departure date : turn the return and departure date into a timeformat in order to compare!
			dDate = $("#date-pick-leave").val().split(" ");
			rDate = $("#date-pick-return").val().split(" ");
			var dMonth = [
				"Jan",
				"Feb",
				"Mar",
				"Apr",
				"May",
				"Jun",
				"Jul",
				"Aug",
				"Sep",
				"Oct",
				"Nov",
				"Dec"
			].indexOf(dDate[1]);
			var rMonth = [
				"Jan",
				"Feb",
				"Mar",
				"Apr",
				"May",
				"Jun",
				"Jul",
				"Aug",
				"Sep",
				"Oct",
				"Nov",
				"Dec"
			].indexOf(rDate[1]);

			var departuredate = new Date(dDate[2], dMonth, dDate[0]); //Year, Month, Date
			var returndate = new Date(rDate[2], rMonth, rDate[0]);
			departuredate = departuredate.getTime();
			returndate = returndate.getTime();

			// Check if the return date does not take place on or before the original date
			if (returndate < departuredate) {
				dateError =
					"Please make sure that the return date comes on or after the departure date you have set.";
				$("#date-pick-leave").addClass("err");
				$("#date-pick-return").addClass("err");
			} else {
				$("#date-pick-leave").removeClass("err");
				$("#date-pick-return").removeClass("err");
			}
		}
	}

	return dateError;
}

function urlbuilder() {
	// get the mandatory values in order to build the url.
	var url = "";
	var arriving = $("#toair").val();
	var departing = $("#fromair").val();
	var returning = "";
	var adults = $("#adults").val();
	var children = $("#children").val();
	var infants = $("#infants").val();
	// we need to ammend this to SAA's date format (example: 25-Nov+2015)!
	var leave = $("#date-pick-leave").val();
	var leave2 = leave.split(" ");
	var leaving = leave2[0] + "-" + leave2[1] + "+" + leave2[2];
	// work out if we are inserting a return option
	returning = "&tripType=O";
	var returnDateRaw = $("#date-pick-return").val();

	if ($("#returnOption").is(":checked") && returnDateRaw.length > 0) {
		// we need to ammend this to SAA's date format (example: 25-Nov+2015)!
		var returnDateRaw2 = returnDateRaw.split(" ");
		var returndate =
			returnDateRaw2[0] + "-" + returnDateRaw2[1] + "+" + returnDateRaw2[2];
		returning = "&tripType=R&toDate=" + returndate;
	}
	var economy = $("#economy").val();

	/* == this is the old method - before we started tracking through GA.
	var url = 'http://www.flysaa.com/za/en/flightSearch!deepLinkingFltAvailabilty.action?departCity='+departing+'&destCity='+arriving+'&fromDate=' + leaving + '&adultCount=' + adults + '&childCount=' + children + '&infantCount=' + infants + '&preferredClass=' + economy + '&flexible=true&SKN=1033' + returning;
	$('#urler').val(url);
	*/

	var GETstring =
		"departCity=" +
		departing +
		"&destCity=" +
		arriving +
		"&fromDate=" +
		leaving +
		"&adultCount=" +
		adults +
		"&childCount=" +
		children +
		"&infantCount=" +
		infants +
		"&preferredClass=" +
		economy +
		"&flexible=true&SKN=1033" +
		returning;

	return GETstring;
}

function updateDeparting(c) {
	// Destroy / empty previous options
	$("#departCity").empty();

	var country = c;
	//alert(country);
	$("#depparting_airport").show();

	var depairports = [];
	depairports.push("selectcity");
	// prepend 'Select City' and make this the 'selected' option
	$("#departCity").prepend(
		'<option value="selectcity">Select Departure City</option>'
	);

	$.each($("#airportoptions option"), function(index, value) {
		var optiontxt = $(this).html();
		var optionval = $(this).val();
		var option_country = optiontxt.split(", ");
		//alert(option_country[1]);
		//split this value at the ',' and see if the second part of the array is
		if (option_country[1] == country || optionval == "selectcity") {
			$("#departCity").append(
				'<option value="' + optionval + '">' + optiontxt + "</option>"
			);
			//add airport code to array
			var aircode = $(this).val();
			depairports.push(aircode);
		}
	});
	// change the value for #fromair field
	$("#fromair").val(depairports[0]);
}

function updateArriving(c) {
	// Destroy / empty previous options
	$("#arrCity").empty();

	var country = c;
	//alert(country);
	$("#arriving_airport").show();

	var arrairports = [];
	arrairports.push("selectcity");
	// prepend 'Select City' and make this the 'selected' option
	$("#arrCity").prepend(
		'<option value="selectcity">Select Arriving City</option>'
	);

	$.each($("#airportoptions option"), function(index, value) {
		var optiontxt = $(this).html();
		var optionval = $(this).val();
		var option_country = optiontxt.split(", ");
		//alert(option_country[1]);
		//split this value at the ',' and see if the second part of the array is
		if (option_country[1] == country || optionval == "selectcity") {
			$("#arrCity").append(
				'<option value="' + optionval + '">' + optiontxt + "</option>"
			);
			//add airport code to array
			var aircode = $(this).val();
			arrairports.push(aircode);
		} else {
			$(this).hide();
		}
	});
	// change the value for #toair field
	$("#toair").val(arrairports[0]);
}

function updateDepartingAirport(c) {
	$("#fromair").val(c);
}

function updateArrivingAirport(c) {
	$("#toair").val(c);
}

/* Book Now Button Functions */

//run this on page load...
updateBookingForm("BFN", "DUR", "Bloemfontein", "Durban", false);

$("body").on("click", ".booknow", function() {
	// We canot use AJAX on codepen so we need to pass
	// the functions to the booking form I have inserted in the page...

	var depTitle = $(this).attr("data-dep-title"),
		arrTitle = $(this).attr("data-arr-title"),
		arr = $(this).attr("data-arr"),
		dep = $(this).attr("data-dep"),
		date = $(this).attr("data-date");
	updateBookingForm(dep, arr, depTitle, arrTitle);

	// $.ajax({
	// 	url: 'XYZ',
	// 	type: 'GET',
	// 	dataType: 'html',
	// 	data: {
	// 		arr : arr,
	// 		dep : dep,
	// 		date : date,
	// 	},
	// }).done(function(data) {
	// 	var windowHeight = $('body').height();
	// 	var marginTop = $(window).scrollTop();
	// 	$('#booknow').show().addClass('opened').html(data).css('margin-top', marginTop+ 'px');
	// 	$(window).trigger('scroll');
	// });
});

function updateBookingForm(dep, arr, depTitle, arrTitle, hideShow = true) {
	if (hideShow) {
		$("#booknow")
			.show()
			.addClass("opened")
			.html(data)
			.css("margin-top", marginTop + "px");
	}
	console.log(dep + " " + arr + " " + depTitle + " " + arrTitle);
	$("#fromair").val(dep);
	$(".depHeading").html(depTitle);
	$("#toair").val(arr);
	$(".arrHeading").html(arrTitle);
}

$("body").on("click", "#closeBookNow", function() {
	$("#booknow").hide();
	$("#booknow").removeClass("opened");
});

$(window).scroll(function() {
	var windowHeight = $("body").height();
	var marginTop = $(window).scrollTop();
	$("#booknow.opened").height(windowHeight + "px");
	// Move the #booknowForm element to
	$("#booknow.opened").css("margin-top", marginTop + "px");
});

$("body").on("click", ".swapout", function() {
	//Values amd titles
	var arrVal = $("#arrCity").val();
	var depVal = $("#departCity").val();
	var arrTitle = $(".arrHeading").html();
	var depTitle = $(".depHeading").html();
	// Swap it all out.
	$(".arrHeading").html(depTitle);
	$(".depHeading").html(arrTitle);
	$("#departCity").val(arrVal);
	$("#fromair").val(arrVal);
	$("#arrCity").val(depVal);
	$("#toair").val(depVal);
});

/* Fligth Schedule Table Toggle Function */
$(document).ready(function() {
	$("body").on("change", "#selectRoute", function() {
		var id = $(this).val();
		$(".flightTable").removeClass("opened");
		$("#route-" + id).addClass("opened");
	});
});