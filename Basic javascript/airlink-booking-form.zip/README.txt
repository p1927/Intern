A Pen created at CodePen.io. You can find this one at https://codepen.io/BrandonBradley/pen/EyrqJQ.

 Created this booking form for a client - Airlink - flyairlink.com
It is a reponsive booking form that will generate a flight scheduke for a selection of destinations you select in the form. 
The booking links will fire a booking form that you can play with to select a flight. 