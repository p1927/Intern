A Pen created at CodePen.io. You can find this one at https://codepen.io/yangg/pen/aOmGJd.

 http://fullcalendar.io/

Interactive demo: http://booking.uedsky.com